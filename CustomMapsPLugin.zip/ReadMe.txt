RL Custom Maps Plugin
=====================
1. Copy CustomMapsPlugin.dll to your BakkesMod plugins folder:
   %appdata%\bakkesmod\bakkesmod\plugins\

2. Launch Rocket League and press F2 to open BakkesMod

3. Go to Plugins > Plugin Manager and enable CustomMapsPlugin

4. Press F6 and type: plugin load CustomMapsPlugin
   Then type: bind F3 "custommaps_open"
   Then type: writeconfig

5. Press F3 anytime to open the Custom Maps browser!

No additional software required.